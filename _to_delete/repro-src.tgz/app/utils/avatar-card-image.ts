// วาด "รูปการ์ดอวตาร" สำหรับแชร์ลงโซเชียล (สัดส่วนแนวตั้ง 9:16 แบบสตอรี่ไอจี) ด้วย canvas
// มีแค่ ชื่อแอป + อวตาร + ข้อความสั้นๆ + ลายตกแต่ง (วาดเองด้วย canvas เลยไม่ต้องลง library เพิ่ม)

interface AvatarCardImageInput {
  nickname: string
  // ชื่อไฟล์รูปอวตารเรียงจากล่างสุดไปบนสุด เช่น ['fx_warm_rosy', 'ear_erect', ...]
  layerCodes: string[]
}

// สีของการ์ด: อ่านจาก tokens.css ตอนวาด (ดู utils/tokens.ts) แก้สีที่ไฟล์นั้นที่เดียว การ์ดแชร์เปลี่ยนตาม
// ค่าในวงเล็บคือค่าสำรอง ใช้เฉพาะตอนอ่านจากหน้าเว็บไม่ได้
function readColors() {
  return {
    ink: readToken('--color-ink', '#292929'),
    muted: readToken('--color-muted', '#6B6264'),
    coral: readToken('--color-coral', '#FE7777'),
    pink: readToken('--color-pink', '#FFD7E2'),
    pinkSoft: readToken('--color-pink-soft', '#FFEBF1'),
    lavender: readToken('--color-lavender', '#CCBBFF'),
    lavenderSoft: readToken('--color-lavender-soft', '#E6DDFF'),
    creamSoft: readToken('--color-cream-soft', '#FFFFEC'),
    predicted: readToken('--color-period-predicted', '#FFA8E6'),
    yellow: readToken('--color-yellow', '#FBFF67'),
    card: readToken('--color-card', '#FFFFFF'),
    bgStart: readToken('--color-bg', '#FFFDFC'),
    bgEnd: readToken('--color-bg-end', '#FFEFF4')
  }
}
let COLORS = readColors()

// ฟอนต์ของการ์ดแชร์ (วาดลง canvas ซึ่งอ่านค่าจาก Tailwind ตรงๆ ไม่ได้)
// ตอนวาดจะดึงฟอนต์จริงที่แอปใช้อยู่มาใช้ (ตั้งที่ tailwind.config.ts) เลยเปลี่ยนฟอนต์ที่เดียวก็เปลี่ยนการ์ดแชร์ตามด้วย
// ค่าด้านล่างเป็นแค่ค่าสำรอง ใช้เมื่ออ่านฟอนต์ของหน้าไม่ได้
const FALLBACK_FONT_FAMILY = 'Anuphan, "Noto Sans Thai", sans-serif'
let FONT_FAMILY = FALLBACK_FONT_FAMILY

function readAppFontFamily() {
  if (typeof document === 'undefined') return
  const family = getComputedStyle(document.body).fontFamily
  FONT_FAMILY = family || FALLBACK_FONT_FAMILY
  COLORS = readColors() // อ่านสีใหม่ทุกครั้งที่วาด เผื่อแก้ token ระหว่างใช้งาน
}

const WIDTH = 1080
const HEIGHT = 1920

function loadImage(src: string): Promise<HTMLImageElement | null> {
  return new Promise((resolve) => {
    const img = new Image()
    img.onload = () => resolve(img)
    img.onerror = () => resolve(null) // รูปไหนโหลดไม่ได้ก็ข้ามไป ไม่ให้ทั้งการ์ดพัง
    img.src = src
  })
}

function roundedRectPath(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  ctx.beginPath()
  ctx.moveTo(x + r, y)
  ctx.arcTo(x + w, y, x + w, y + h, r)
  ctx.arcTo(x + w, y + h, x, y + h, r)
  ctx.arcTo(x, y + h, x, y, r)
  ctx.arcTo(x, y, x + w, y, r)
  ctx.closePath()
}

// ตัดบรรทัดตามความกว้าง ภาษาไทยไม่มีเว้นวรรค เลยใช้ Intl.Segmenter ตัดตามคำ
// (ถ้าเบราว์เซอร์ไม่มี จะตัดทีละตัวอักษรแทน)
function wrapText(ctx: CanvasRenderingContext2D, text: string, maxWidth: number): string[] {
  type SegmenterCtor = new (locale: string, options: { granularity: string }) => {
    segment(input: string): Iterable<{ segment: string }>
  }
  const Segmenter = (Intl as unknown as { Segmenter?: SegmenterCtor }).Segmenter
  const pieces = Segmenter
    ? Array.from(new Segmenter('th', { granularity: 'word' }).segment(text), s => s.segment)
    : Array.from(text)

  const lines: string[] = []
  let line = ''
  for (const piece of pieces) {
    const attempt = line + piece
    if (line && ctx.measureText(attempt).width > maxWidth) {
      lines.push(line.trimEnd())
      line = piece.trimStart()
    } else {
      line = attempt
    }
  }
  if (line.trim()) lines.push(line.trimEnd())
  return lines
}

// ---------- ลายตกแต่ง ----------

// ประกายดาว 4 แฉก (เว้าเข้าตรงกลาง)
function drawStar(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, color: string, rotation = 0) {
  ctx.save()
  ctx.translate(x, y)
  ctx.rotate(rotation)
  ctx.fillStyle = color
  ctx.beginPath()
  const angles = [-90, 0, 90, 180].map(a => (a * Math.PI) / 180)
  ctx.moveTo(0, -r)
  for (let i = 0; i < 4; i++) {
    const next = angles[(i + 1) % 4]!
    const mid = angles[i]! + Math.PI / 4
    ctx.quadraticCurveTo(Math.cos(mid) * r * 0.16, Math.sin(mid) * r * 0.16, Math.cos(next) * r, Math.sin(next) * r)
  }
  ctx.closePath()
  ctx.fill()
  ctx.restore()
}

function drawGlow(ctx: CanvasRenderingContext2D, x: number, y: number, r: number, rgb: string, alpha: number) {
  const g = ctx.createRadialGradient(x, y, 0, x, y, r)
  g.addColorStop(0, `rgba(${rgb}, ${alpha})`)
  g.addColorStop(1, `rgba(${rgb}, 0)`)
  ctx.fillStyle = g
  ctx.fillRect(x - r, y - r, r * 2, r * 2)
}

export async function renderAvatarCardImage(input: AvatarCardImageInput): Promise<Blob> {
  readAppFontFamily()
  // รอให้ฟอนต์ที่ใช้โหลดเสร็จก่อนวาด ไม่งั้นตัวหนังสือจะเป็นฟอนต์สำรอง
  if (document.fonts) {
    await Promise.all([
      document.fonts.load(`700 72px ${FONT_FAMILY}`),
      document.fonts.load(`500 44px ${FONT_FAMILY}`)
    ]).catch(() => {})
  }

  const images = await Promise.all(input.layerCodes.map(code => loadImage(avatarLayerSrc(code))))
  // มุมขวาบน: โลโก้วงกลม (พระจันทร์ + กระต่าย) วางเหนือชื่อ MoonieCalm แบบบรรทัดเดียว (wordmark-one.svg) เหมือนหน้าแรกของแอป
  // มุมขวาล่าง: คิวอาร์โค้ด (ไฟล์คิวอาร์อยู่ที่ public/brand/qr.png)
  const [moonImg, rabbitImg, wordmarkImg, qrImg] = await Promise.all([
    loadImage('/brand/moon.svg'),
    loadImage('/brand/rabbit.svg'),
    loadImage('/brand/wordmark-one.svg'),
    loadImage('/brand/qr.png')
  ])

  const canvas = document.createElement('canvas')
  canvas.width = WIDTH
  canvas.height = HEIGHT
  const ctx = canvas.getContext('2d')!

  // ----- คำนวณความสูงเนื้อหาทั้งก้อน แล้ววางให้อยู่กึ่งกลางแนวตั้ง (เว้นที่ด้านล่างไว้ให้คิวอาร์) -----
  // ----- มุมขวาบน: โลโก้วงกลม (บน) + ชื่อ MoonieCalm (ล่าง) จัดกึ่งกลางกันเอง แล้วชิดขอบขวาของการ์ด -----
  // อยากให้โลโก้ใหญ่/เล็กลง แก้ที่ logoSize กับ wordW สองตัวนี้ ที่เหลือคำนวณตามเอง
  // wordmark-one.svg สัดส่วน 387 x 71 (ถ้าเปลี่ยนไฟล์ชื่อใหม่แล้วขนาดไม่เท่านี้ ให้แก้เลข 387 กับ 71 ตามไฟล์)
  const WM_W = 387
  const WM_H = 71
  const logoSize = 190 // วงกลมโลโก้
  const wordW = 340
  const wordH = Math.round((wordW * WM_H) / WM_W)
  const lockGap = 14 // ระยะระหว่างวงกลมกับชื่อ
  const lockW = Math.max(logoSize, wordW)
  const lockMarginRight = 90 // ขอบขวา (เผื่อที่ให้ประกายด้านขวาของชื่อ)
  const lockMarginTop = 70
  const lockX = WIDTH - lockMarginRight - lockW
  const logoX = lockX + (lockW - logoSize) / 2
  const logoY = lockMarginTop
  const wordX = lockX + (lockW - wordW) / 2
  const wordY = logoY + logoSize + lockGap
  const lockBottom = wordY + wordH
  // ----- มุมขวาล่าง: คิวอาร์ ชิดขวา + ข้อความ "ลองเล่นได้ที่" อยู่ฝั่งซ้าย -----
  const rightMargin = 80 // ขอบขวาของคิวอาร์
  const bottomMargin = 80 // ขอบล่างของคิวอาร์
  const qrPlate = 216
  const qrX = WIDTH - rightMargin - qrPlate
  const qrY = HEIGHT - bottomMargin - qrPlate
  const avatarSize = 840 // อวตารไม่มีกรอบ วางเต็มๆ
  const textGap = 14 // ระยะจากรูปอวตารถึงข้อความ (ข้อความอยู่ใต้รูป ไม่ทับตัวอวตาร ไม่มีกรอบ)
  const textW = WIDTH - 260 // ความกว้างที่ข้อความยินดีด้วยใช้ได้ (ชื่อยาวจะถูกลดขนาดตัวอักษรให้พอดี)
  const title = `ยินดีด้วย ${input.nickname}!`
  // ชื่อยาวมาก ค่อยๆ ลดขนาดตัวอักษรจนพอดีกรอบ ถ้าเล็กสุดแล้วยังไม่พอก็ตัดขึ้นบรรทัดใหม่
  let titleSize = 62
  ctx.font = `700 ${titleSize}px ${FONT_FAMILY}`
  while (titleSize > 44 && ctx.measureText(title).width > textW) {
    titleSize -= 4
    ctx.font = `700 ${titleSize}px ${FONT_FAMILY}`
  }
  const titleLines = wrapText(ctx, title, textW)
  const titleLineH = Math.round(titleSize * 1.35)
  const subtitleSize = 36
  const subtitleH = 50
  const textH = titleLines.length * titleLineH + 12 + subtitleH

  const contentH = avatarSize + textGap + textH
  // อวตาร + ข้อความ อยู่กึ่งกลางช่องว่างระหว่าง "ใต้ชื่อโลโก้มุมขวาบน" กับ "บนสุดของคิวอาร์" (ขยับขึ้น 30 ให้ดูสมดุล)
  const top = Math.round(lockBottom + (qrY - lockBottom - contentH) / 2 - 30)
  const avatarX = (WIDTH - avatarSize) / 2
  const avatarY = top
  const avatarCy = avatarY + avatarSize / 2
  const textY = avatarY + avatarSize + textGap

  // ----- พื้นหลัง: ตรงกลางสีขาว ไล่ออกไปเป็นชมพูอ่อน (สีแบรนด์) -----
  const bg = ctx.createLinearGradient(0, 0, 0, HEIGHT)
  bg.addColorStop(0, COLORS.card)
  bg.addColorStop(0.5, COLORS.pinkSoft)
  bg.addColorStop(1, COLORS.pink)
  ctx.fillStyle = bg
  ctx.fillRect(0, 0, WIDTH, HEIGHT)
  drawGlow(ctx, WIDTH / 2, avatarCy, 720, hexToRgbText(COLORS.card), 1) // แสงขาวด้านหลังอวตาร ให้ขอบรูปกลืนกับพื้น
  drawGlow(ctx, 120, 1750, 560, hexToRgbText(COLORS.pink), 0.8) // ชมพู ล่างซ้าย
  drawGlow(ctx, 980, 260, 460, hexToRgbText(COLORS.pink), 0.6) // ชมพู ขวาบน

  // ----- ลายตกแต่ง: ประกายดาวแค่ไม่กี่ดวง ไม่ให้รก -----
  drawStar(ctx, 120, 280, 38, COLORS.coral, -0.2)
  drawStar(ctx, 960, 400, 28, COLORS.lavender)
  drawStar(ctx, 110, 1180, 30, COLORS.predicted)
  drawStar(ctx, 975, 1240, 36, COLORS.lavender, 0.15)

  // ----- โลโก้มุมขวาบน: วงกลมอยู่บนชื่อ (เหมือนหน้าแรก) -----
  if (moonImg) {
    // 1) พระจันทร์
    ctx.drawImage(moonImg, logoX, logoY, logoSize, logoSize)
    // 2) กระต่าย: ตัดให้อยู่ในวงกลมเหมือนในแอป
    if (rabbitImg) {
      ctx.save()
      ctx.beginPath()
      ctx.arc(logoX + logoSize / 2, logoY + logoSize / 2, logoSize / 2, 0, Math.PI * 2)
      ctx.clip()
      ctx.drawImage(rabbitImg, logoX, logoY, logoSize, logoSize)
      ctx.restore()
    }
    // 3) ประกายในวงกลมโลโก้ (ตำแหน่งตามโลโก้ในแอป วัดบนกรอบ 240 แล้วย่อ/ขยายตามขนาด)
    const k = logoSize / 240
    const sparks = [
      { x: 20, y: 130, s: 20, color: COLORS.coral },
      { x: 191, y: 145, s: 20, color: COLORS.creamSoft },
      { x: 9, y: 114, s: 13, color: COLORS.creamSoft },
      { x: 220, y: 120, s: 13, color: COLORS.lavenderSoft },
      { x: 13, y: 163, s: 13, color: COLORS.lavenderSoft },
      { x: 206, y: 169, s: 10, color: COLORS.coral }
    ]
    for (const sp of sparks) {
      drawStar(ctx, logoX + (sp.x + sp.s / 2) * k, logoY + (sp.y + sp.s / 2) * k, (sp.s / 2) * k * 1.3, sp.color)
    }
  }

  // ชื่อ MoonieCalm ใต้วงกลม (wordmark-one.svg = โลโก้หลัก ตัวหนังสือเท่านั้น ไม่มีประกายในไฟล์)
  if (wordmarkImg) {
    ctx.drawImage(wordmarkImg, wordX, wordY, wordW, wordH)
  } else {
    // ถ้ารูปชื่อโหลดไม่ได้ ใช้ตัวหนังสือแทน
    ctx.textAlign = 'center'
    ctx.textBaseline = 'alphabetic'
    ctx.font = `700 52px ${FONT_FAMILY}`
    ctx.fillStyle = COLORS.ink
    ctx.fillText('MoonieCalm', wordX + wordW / 2, wordY + wordH - 6)
  }
  // ประกายฟรุ้งฟริ้งรอบชื่อ (ตำแหน่งวัดบนกรอบไฟล์ชื่อ 387 x 71 แล้วย่อ/ขยายตาม wordW)
  // x, y = กึ่งกลางประกาย, r = รัศมี  อยากเพิ่ม/ลบ/ย้ายประกาย แก้ในรายการนี้ได้เลย
  const wk = wordW / WM_W
  const nameSparks = [
    { x: -16, y: 10, r: 12, color: COLORS.lavender }, // ซ้ายบน
    { x: -6, y: 58, r: 7, color: COLORS.coral }, // ซ้ายล่าง
    { x: 150, y: 9, r: 7, color: COLORS.predicted }, // ข้างหูกระต่ายบนตัว i (ซ้าย)
    { x: 212, y: 12, r: 9, color: COLORS.lavender }, // ข้างหูกระต่ายบนตัว i (ขวา)
    { x: 403, y: 12, r: 11, color: COLORS.yellow }, // ขวาบน
    { x: 398, y: 58, r: 7, color: COLORS.coral } // ขวาล่าง
  ]
  for (const sp of nameSparks) {
    drawStar(ctx, wordX + sp.x * wk, wordY + sp.y * wk, sp.r * wk * 1.3, sp.color)
  }

  // ----- อวตาร: ไม่มีกรอบ ไม่มีเงา เบลอขอบ 4 ด้านให้กลืนกับพื้นหลัง -----
  // วาดทุกเลเยอร์ลงผืนผ้าใบแยกก่อน แล้วค่อยทำขอบจางแล้วแปะลงการ์ด
  const avatarCanvas = document.createElement('canvas')
  avatarCanvas.width = avatarSize
  avatarCanvas.height = avatarSize
  const actx = avatarCanvas.getContext('2d')!
  for (const img of images) {
    if (img) actx.drawImage(img, 0, 0, avatarSize, avatarSize)
  }
  // ขอบจาง: ใช้ destination-in กับไล่สีโปร่งใส -> ทึบ ทีละด้าน (ไม่ใช้ ctx.filter เพราะ Safari บางรุ่นไม่รองรับ)
  const feather = 90
  actx.globalCompositeOperation = 'destination-in'
  const edges: [number, number, number, number][] = [
    [0, 0, feather, 0], // ซ้าย
    [avatarSize, 0, avatarSize - feather, 0], // ขวา
    [0, 0, 0, feather], // บน
    [0, avatarSize, 0, avatarSize - feather] // ล่าง
  ]
  for (const [x0, y0, x1, y1] of edges) {
    const g = actx.createLinearGradient(x0, y0, x1, y1)
    g.addColorStop(0, 'rgba(0, 0, 0, 0)')
    g.addColorStop(1, 'rgba(0, 0, 0, 1)')
    actx.fillStyle = g
    actx.fillRect(0, 0, avatarSize, avatarSize)
  }
  // จางวงกลมอีกชั้น ให้มุมสี่เหลี่ยมของรูปหายไป เหลือแต่แสงฟุ้งกลมๆ (ตัวละครอยู่กลางภาพ ไม่โดนจาง)
  const c = avatarSize / 2
  const radial = actx.createRadialGradient(c, c, avatarSize * 0.42, c, c, avatarSize * 0.68)
  radial.addColorStop(0, 'rgba(0, 0, 0, 1)')
  radial.addColorStop(1, 'rgba(0, 0, 0, 0)')
  actx.fillStyle = radial
  actx.fillRect(0, 0, avatarSize, avatarSize)
  ctx.drawImage(avatarCanvas, avatarX, avatarY)

  // ----- ข้อความยินดีด้วย: อยู่ใต้รูปอวตาร (ไม่มีกรอบ ไม่ทับตัวอวตาร) -----
  // จัดกึ่งกลางเอง (วัดความกว้างแล้วคำนวณ x) แทนการใช้ textAlign = 'center'
  // เพราะบางเครื่อง/เบราว์เซอร์ไม่ทำตาม 'center' ทำให้ข้อความไปเริ่มที่กลางการ์ดแล้วล้นออกด้านขวา (ดูเหมือนเอียง)
  ctx.textAlign = 'left'
  ctx.textBaseline = 'alphabetic'
  const fillCentered = (text: string, y: number) => {
    const w = ctx.measureText(text).width
    ctx.fillText(text, Math.round((WIDTH - w) / 2), y)
  }
  ctx.fillStyle = COLORS.ink
  ctx.font = `700 ${titleSize}px ${FONT_FAMILY}`
  titleLines.forEach((line, i) => {
    fillCentered(line, textY + titleSize + i * titleLineH)
  })
  ctx.fillStyle = COLORS.muted
  ctx.font = `500 ${subtitleSize}px ${FONT_FAMILY}`
  fillCentered('นี่คืออวตารตัวจิ๋วของคุณ', textY + titleLines.length * titleLineH + 12 + subtitleSize + 4)

  // ----- คิวอาร์โค้ด (แผ่นขาวรองให้สแกนง่าย) + ที่อยู่เว็บอยู่ฝั่งซ้าย (ตำแหน่งคำนวณไว้ด้านบนแล้ว) -----
  if (qrImg) {
    ctx.save()
    ctx.shadowColor = `rgba(${hexToRgbText(COLORS.coral)}, 0.2)`
    ctx.shadowBlur = 30
    ctx.shadowOffsetY = 10
    ctx.fillStyle = COLORS.card
    roundedRectPath(ctx, qrX, qrY, qrPlate, qrPlate, 28)
    ctx.fill()
    ctx.restore()
    const pad = 14
    ctx.drawImage(qrImg, qrX + pad, qrY + pad, qrPlate - pad * 2, qrPlate - pad * 2)
  }
  // ที่อยู่เว็บ ใช้ที่อยู่ที่เปิดอยู่ตอนกดแชร์ (ถ้าไม่มีคิวอาร์จะอยู่กึ่งกลางล่าง)
  const hasQr = !!qrImg
  ctx.textAlign = hasQr ? 'left' : 'center'
  const textX = hasQr ? 100 : WIDTH / 2
  const midY = qrY + qrPlate / 2
  ctx.fillStyle = COLORS.muted
  ctx.font = `500 40px ${FONT_FAMILY}`
  ctx.fillText('ลองเล่นได้ที่', textX, midY - 6)
  let hostSize = 46
  ctx.font = `700 ${hostSize}px ${FONT_FAMILY}`
  const maxHostW = hasQr ? qrX - 100 - 30 : WIDTH - 200
  while (hostSize > 28 && ctx.measureText(window.location.host).width > maxHostW) {
    hostSize -= 2
    ctx.font = `700 ${hostSize}px ${FONT_FAMILY}`
  }
  ctx.fillStyle = COLORS.ink
  ctx.fillText(window.location.host, textX, midY + 54)

  return await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(blob => (blob ? resolve(blob) : reject(new Error('สร้างรูปการ์ดไม่สำเร็จ'))), 'image/png')
  })
}
